package com.example.graphql.controller;

import com.example.graphql.model.BookDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.graphql.data.method.annotation.Argument;
import org.springframework.graphql.data.method.annotation.MutationMapping;
import org.springframework.graphql.data.method.annotation.QueryMapping;
import org.springframework.stereotype.Controller;
import com.example.graphql.model.Book;
import com.example.graphql.model.Author;
import com.example.graphql.service.BookService;
import com.example.graphql.service.AuthorService;

@Controller
public class BookController {

    @Autowired
    private BookService bookService;

    @Autowired
    private AuthorService authorService;

    @MutationMapping
    public Book addBook(@Argument String id, @Argument String name, @Argument int pageCount, @Argument String authorId) {
        Book book = new Book(id, name, pageCount, authorId);
        return bookService.saveBook(book);
    }

    @QueryMapping
    public Book bookById(@Argument String id) {
        return bookService.getBookById(id);
    }

    @QueryMapping
    public BookDetails bookDetailsById(@Argument String id) {
        Book book = bookService.getBookById(id);
        Author author = authorService.getAuthorById(book.getAuthorId());
        return new BookDetails(book.getId(), book.getName(), book.getPageCount(), author.getFirstName() + " " + author.getLastName());
    }
}
