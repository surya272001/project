package com.example.graphql.controller;

public class AuthorController {
}
