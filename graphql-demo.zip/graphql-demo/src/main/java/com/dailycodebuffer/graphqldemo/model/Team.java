package com.dailycodebuffer.graphqldemo.model;

public enum Team {
    CSK,
    MI,
    DC,
    GT,
    RCB
}
