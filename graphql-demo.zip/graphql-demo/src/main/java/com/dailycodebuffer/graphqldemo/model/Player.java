package com.dailycodebuffer.graphqldemo.model;

public record Player(Integer Id, String name, Team team) {
}
